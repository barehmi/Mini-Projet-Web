<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <title>Liste des Locations</title>
    <link rel="stylesheet" href="../css/liste.css">
</head>

<body>
    <?php
    require_once('../Controller/Location.php');
    $lc = new Location();
    $res = $lc->listeLoca();
    ?>
    <center>
        <h1>Liste Des Locations :</h1>
        <table border='2' class='styled-table'>
            <thead>
            <tr>
                <th colspan='3'><u>Location</u></th>
                <th colspan='2'><u>Voiture</u></th>
                <th colspan='3'><u>Client</u></th>
            </tr>
            <thead>
                <tbody>
            <tr class='ST'>
                <th>Identifiant : </th>
                <th>Nbr de jours :</th>
                <th>Date :</th>
                <th>Marque :</th>
                <th>Numéro de série :</th>
                <th>Numéro CIN :</th>
                <th>Nom :</th>
                <th>Prénom :</th>
            </tr>

            <?php
            foreach ($res as $row) {
                echo "<tr class='BC'><th>$row[idLocat]</th>
                        <th>$row[nbrJour]</th>
                        <th>$row[dateLoc]</th>
                        <th>$row[marque]</th>
                        <th>$row[numSerie]</th>
                        <th>$row[ncin]</th>
                        <th>$row[nom]</th>
                        <th>$row[prenom]</th>
                        </tr>";
            }
            ?>
                </tbody>
        </table>
        <table>
        <br>
           <a href="ajouterLoc.php"><button type='button'>Ajouter Location</button></a>
           <a href="home.html"><button type='button'>Accueil</button></a>
</body>
</center>
</body>

</html>