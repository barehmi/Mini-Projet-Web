<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <title>Ajouter Client</title>
    <link rel="stylesheet" href="../css/pages.css">
</head>

<body>
    <center>
    <h1>Ajouter Client :</h1>
    <fieldset>
        <legend>Nouveau Client :</legend>
        <form name="form" method="Post" action="../Controller/ajoutClient_action.php">
            <br>
            <table class="tabform">
                <tr>
                    <td>Numéro Cin : </td>
                    <td><input type="text" name="cinclient" id='cinclient' required></td>
                </tr>
                <tr>
                    <td>Nom : </td>
                    <td><input type="text" name="nomclient" id='nomclient' required></td>
                </tr>
                <tr>
                    <td>Prénom : </td>
                    <td><input type="text" name="preclient" id='preclient' required></td>
                </tr>
                <tr>
                    <td>Télèphone : </td>
                    <td><input type="text" name="telclient" id='telclient' required></td>
                </tr>
                <tr><th colspan="2">
                    <br>
                    <input type="submit" name="submit" value="Enregistrer">
                   <a href="home.html"><button type="button" name="annuler">Annuler</button></a></th>
                </tr>
            </table>
        </form>
    </fieldset>
    <center>
</body>

</html>