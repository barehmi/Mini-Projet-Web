<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <title>Recherche Voiture</title>
    <link rel="stylesheet" href="../css/liste.css">
</head>

<body>
    <center>
        <?php
        require_once('Voiture.php');
        $vt = new Voiture();
        $res = $vt->rechercher($_POST['Voit']);
        if ($_POST['Voit'] == 0) {
            echo "<script>alert('Selectioner type carburant svp !');window.history.go(-1); </script>";
            return false;
        } else if ($_POST['Voit'] == "Essence") {
            echo "<h1>Liste Voitures Essence : </h1>";
        } else {
            echo "<h1>Liste Voitures Diesel : </h1>";
        }
        if ($res->rowCount() > 0) {

            echo "<table border='2' class='styled-table'>
           <thead><tr><th colspan='3'>Voitures :</th></tr></thead>
             <tbody>
                <tr class='ST'>
                 <th>Numéro serie :</th>
                <th>Marque :</th>
                 <th>Prix Location</th></tr>";
            foreach ($res as $row) {
                echo "<tr class='BC'><th>$row[numSerie]</th>
              <th>$row[marque]</th>
              <th>$row[prixLocation]</th>
              </tr>";
            }
            echo "</tbody></table>
            <br> <a href='../view/rechercheVoiture.html'><button type='button' name='Retour'>Retour</button></a>";
        } else {
            echo "<script>alert('Aucune voiture trouvée pour ce type de carburant !'); window.history.go(-1);</script>";
            return false;
        }
        ?>


</body>
</center>
</body>

</html>