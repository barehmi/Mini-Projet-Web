<?php
require_once('Client.php');
$cl=new Client();
$cl->insert($_POST['cinclient'],$_POST['nomclient'],$_POST['preclient'],$_POST['telclient']);
header('Location:../view/listeClients.php');
