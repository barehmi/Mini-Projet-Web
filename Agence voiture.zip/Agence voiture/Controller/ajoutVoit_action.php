<?php
require_once('Voiture.php');
$vt=new Voiture();
$vt->insert($_POST['numserie'],$_POST['marvoit'],$_POST['carbu'],$_POST['prixloc']);
header('Location:../view/ajoutVoit.php');
