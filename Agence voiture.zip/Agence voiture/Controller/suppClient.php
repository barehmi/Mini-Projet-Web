<?php
require_once('Client.php');
$cl=new Client();
$cl-> delete($_POST['r']);
header('Location:../view/listeClients.php');
