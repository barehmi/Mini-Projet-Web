<?php
include_once("../model/Modele.php");
class Location extends Modele
{
    public $idLoc, $idClient, $idVoit, $nbrJ, $dateLoc;
    function __construct($id = "", $idClient = "", $idVoit = "", $nbrJ = "", $dateLoc = "")
    {
        $this->idLoc = $id;
        $this->idClient = $idClient;
        $this->idVoit = $idVoit;
        $this->nbrJ = $nbrJ;
        $this->dateLoc = $dateLoc;
        parent::__construct();
    }
    function insert($idClient, $idVoit, $nbrJ, $dateLoc)
    {
        $query = "insert into location(idClient,idVoiture,nbrJour,dateLoc) values (?, ?, ?, ?)";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($idClient, $idVoit, $nbrJ, $dateLoc));
    }
    function delete($idLoc)
    {
        $query = "delete from location where idLocat=?";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($idLoc));
    }
    function listeLoca()
    {
        $query = "select idLocat,nbrJour,dateLoc,marque,numSerie,ncin,nom,prenom from location l,voiture v ,client c where (l.idClient=c.idClient) and (l.idVoiture=v.idVoiture)";
        $res = $this->pdo->prepare($query);
        $res->execute();
        return $res;
    }
}
